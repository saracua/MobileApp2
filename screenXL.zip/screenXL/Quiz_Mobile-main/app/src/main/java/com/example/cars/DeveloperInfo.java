package com.example.cars;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class DeveloperInfo extends AppCompatActivity {

    private User user;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_developer_info);


        if(getIntent().hasExtra("userObject")){
            user = (User) getIntent().getSerializableExtra("userObject");
            Log.e("userobject",user.getFirstName()+user.getLastName());
        }
    }

    public void onBackPressed() {
        Toast.makeText(DeveloperInfo.this,"Clicked",Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(DeveloperInfo.this,MainActivity.class);
        intent.putExtra("userObject", user);
        getApplicationContext().startActivity(intent);

            }
        }

